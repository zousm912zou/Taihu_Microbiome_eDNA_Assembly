###########################################################
# Reproduce Figure 1, Figure S3 and Figure S4 panels 
# Example for a single microbial group
# Input files:
#   ASV.csv, ENV.csv, Group.csv, JWD.csv, Taxonomy.csv
#
# Outputs:
#   Stacked barplot
#   Phylum boxplot with Wilcoxon tests
#   Indicator species analysis
#   Indicator × environment correlation heatmap
###########################################################

library(ggplot2)
library(dplyr)
library(tidyr)
library(reshape2)
library(RColorBrewer)
library(ggpubr)

###########################################################
# 1. Load data
###########################################################
otu_table  <- read.csv("ASV.csv", row.names = 1, check.names = FALSE)
taxonomy   <- read.csv("Taxonomy.csv", stringsAsFactors = FALSE)
group_info <- read.csv("Group.csv", stringsAsFactors = FALSE)

taxonomy$OTU <- trimws(taxonomy$OTU)

otu_table <- otu_table[rowSums(otu_table) > 0, ]
otu_table <- otu_table[rownames(otu_table) %in% group_info$Sample, ]

otu_t <- as.data.frame(t(otu_table))
otu_t$OTU <- rownames(otu_t)

taxonomy_sub <- taxonomy[, c("OTU", "Phylum")]
otu_tax <- merge(otu_t, taxonomy_sub, by="OTU")
otu_tax$Phylum[otu_tax$Phylum == ""] <- "unclassified"

sample_cols <- setdiff(names(otu_tax), c("OTU","Phylum"))
otu_long <- melt(
  otu_tax,
  id.vars=c("OTU","Phylum"),
  measure.vars=sample_cols,
  variable.name="Sample",
  value.name="Abundance"
)

otu_long <- merge(otu_long, group_info, by="Sample")

###########################################################
# 2. Identify Top10 phyla in Spring & Summer
###########################################################
spring_data <- otu_long %>% filter(Season == "Spring")
summer_data <- otu_long %>% filter(Season == "Summer")

top10_spring <- spring_data %>% 
  group_by(Phylum) %>% summarise(Total=sum(Abundance)) %>% 
  arrange(desc(Total)) %>% slice(1:10) %>% pull(Phylum)

top10_summer <- summer_data %>% 
  group_by(Phylum) %>% summarise(Total=sum(Abundance)) %>% 
  arrange(desc(Total)) %>% slice(1:10) %>% pull(Phylum)

legend_levels <- sort(unique(c(top10_spring, top10_summer, "Other")))
palette_colors <- colorRampPalette(brewer.pal(12,"Set3"))(length(legend_levels))
names(palette_colors) <- legend_levels

###########################################################
# 3. Stacked barplot
###########################################################
make_stacked <- function(df, top10_set, title_text) {
  df_sum <- df %>%
    mutate(Phylum = ifelse(Phylum %in% top10_set, Phylum, "Other")) %>%
    group_by(Region, Phylum) %>%
    summarise(TotalAbundance = sum(Abundance), .groups="drop") %>%
    group_by(Region) %>%
    mutate(RelAbundance = TotalAbundance / sum(TotalAbundance)) %>%
    ungroup() %>%
    mutate(Phylum = factor(Phylum, levels = legend_levels))

  ggplot(df_sum, aes(Region, RelAbundance, fill = Phylum)) +
    geom_bar(stat="identity") +
    labs(title=title_text, x="Region", y="Relative Abundance") +
    theme_minimal(base_size=22) +
    theme(
      plot.title = element_text(size=26),
      axis.text.x = element_text(angle=45, hjust=1, size=20),
      axis.text.y = element_text(size=20),
      legend.text = element_text(size=20)
    ) +
    scale_fill_manual(values=palette_colors)
}

p_spring <- make_stacked(spring_data, top10_spring, "Spring")
p_summer <- make_stacked(summer_data, top10_summer, "Summer")

###########################################################
# 4. Boxplot + Wilcoxon p-values
###########################################################
otu_rel <- otu_long %>%
  group_by(Sample) %>%
  mutate(RelAbundance = Abundance / sum(Abundance)) %>%
  ungroup()

otu_rel$Phylum <- ifelse(
  otu_rel$Phylum %in% legend_levels[-length(legend_levels)],
  otu_rel$Phylum,
  "Other"
)
otu_rel$Phylum <- factor(otu_rel$Phylum, levels=legend_levels)

season_colors <- c("Spring"="#F4A582", "Summer"="#92C5DE")

max_rel <- max(otu_rel$RelAbundance, na.rm=TRUE)

p_box <- ggplot(otu_rel, aes(Phylum, RelAbundance)) +
  geom_boxplot(
    aes(fill=Season),
    position=position_dodge(0.8),
    alpha=0.85,
    color=NA
  ) +
  geom_jitter(
    aes(color=Season),
    position=position_jitterdodge(jitter.width=0.15, dodge.width=0.8),
    alpha=0.5, size=1.2
  ) +
  stat_compare_means(
    aes(group=Season),
    method="wilcox.test",
    label="p.format",
    label.y = max_rel * 1.1,
    size=3,
    color="black"
  ) +
  labs(title="Seasonal Differences in Phylum-level Composition",
       x="Phylum", y="Relative Abundance") +
  theme_bw(base_size=22) +
  theme(
    plot.title=element_text(size=26),
    axis.text.x=element_text(angle=45, hjust=1, size=18),
    axis.text.y=element_text(size=18),
    legend.text=element_text(size=20)
  ) +
  scale_fill_manual(values=season_colors) +
  scale_color_manual(values=season_colors)

###########################################################
# 5. Save images
###########################################################
ggsave("Example_Stacked_Spring.png", p_spring, width=8, height=6, dpi=320)
ggsave("Example_Stacked_Summer.png", p_summer, width=8, height=6, dpi=320)
ggsave("Example_Phylum_Boxplot.png", p_box, width=12, height=6, dpi=320)

###########################################################
# Part 2 — Indicator Species × Environmental Drivers
###########################################################
library(indicspecies)
library(gridExtra)

###########################################################
# 1. Read datasets
###########################################################
otu_table <- read.csv("ASV.csv", row.names = 1, check.names = FALSE)
env_factors <- read.csv("ENV.csv", row.names = 1, check.names = FALSE)

taxonomy <- read.csv("Taxonomy.csv", row.names = 1, check.names = FALSE) %>%
  mutate(across(everything(), ~ trimws(.))) %>%
  mutate(across(everything(), ~ na_if(., ""))) %>%
  mutate(across(everything(), ~ na_if(., "NA")))

group_info <- read.csv("Group.csv", row.names = 1, check.names = FALSE) %>%
  tibble::rownames_to_column("SampleID") %>%
  mutate(Season = factor(Season))

###########################################################
# 2. Keep only Spring / Summer
###########################################################
group_info_ss <- group_info %>%
  filter(Season %in% c("Spring", "Summer"))

###########################################################
# 3. Align sample names
###########################################################
common_samples <- Reduce(intersect, list(
  rownames(otu_table),
  rownames(env_factors),
  group_info_ss$SampleID
))

otu_ss <- otu_table[common_samples, , drop=FALSE]
env_factors_ss <- env_factors[common_samples, , drop=FALSE]
group_info_ss <- group_info_ss %>%
  filter(SampleID %in% common_samples) %>%
  arrange(SampleID)

otu_ss <- otu_ss[order(rownames(otu_ss)), ]
env_factors_ss <- env_factors_ss[order(rownames(env_factors_ss)), ]
group_info_ss <- group_info_ss[order(group_info_ss$SampleID), ]

###########################################################
# 4. Align OTUs with taxonomy + relative abundance
###########################################################
common_otus <- intersect(colnames(otu_ss), rownames(taxonomy))
otu_ss <- otu_ss[, common_otus, drop=FALSE]

taxonomy_filt <- taxonomy[common_otus, , drop=FALSE] %>%
  tibble::rownames_to_column("OTU")

otu_ss <- otu_ss[, colSums(otu_ss) > 0, drop=FALSE]
otu_ss <- otu_ss[rowSums(otu_ss) > 0, , drop=FALSE]
group_info_ss <- group_info_ss %>% filter(SampleID %in% rownames(otu_ss))

otu_rel <- otu_ss / rowSums(otu_ss)

###########################################################
# 5. Indicator species analysis
###########################################################
set.seed(123)
res_indval <- multipatt(
  otu_rel,
  group_info_ss$Season,
  func="IndVal.g",
  control=how(nperm=9999)
)

signif_df <- as.data.frame(res_indval$sign) %>%
  tibble::rownames_to_column("OTU") %>%
  filter(p.value < 0.01)

orig_cols <- names(res_indval$sign)[1:length(levels(group_info_ss$Season))]
names(signif_df)[match(orig_cols, names(signif_df))] <- levels(group_info_ss$Season)

signif_df <- signif_df %>% filter(OTU %in% colnames(otu_rel))

spring_otus <- signif_df %>% filter(Spring == 1) %>% pull(OTU)
summer_otus <- signif_df %>% filter(Summer == 1) %>% pull(OTU)

get_fallback <- function(season_name) {
  otu_rel %>%
    tibble::rownames_to_column("SampleID") %>%
    pivot_longer(-SampleID, names_to="OTU", values_to="Abundance") %>%
    left_join(group_info_ss, by="SampleID") %>%
    filter(Season == season_name) %>%
    group_by(OTU) %>%
    summarise(MeanAbundance = mean(Abundance)) %>%
    arrange(desc(MeanAbundance)) %>%
    slice(1:5) %>%
    pull(OTU)
}

if (length(spring_otus) == 0) spring_otus <- get_fallback("Spring")
if (length(summer_otus) == 0) summer_otus <- get_fallback("Summer")

###########################################################
# 6. Correlation between indicator OTUs and env variables
###########################################################
cor_env_indicator <- function(ind_otus, season_label) {

  season_samples <- group_info_ss %>%
    filter(Season == season_label) %>%
    pull(SampleID)

  otu_sub <- otu_rel[season_samples, ind_otus, drop=FALSE]
  env_sub <- env_factors_ss[season_samples, , drop=FALSE]
  env_sub <- env_sub[, colSums(is.na(env_sub)) == 0, drop=FALSE]

  cor_mat <- matrix(
    NA, nrow=ncol(otu_sub), ncol=ncol(env_sub),
    dimnames=list(colnames(otu_sub), colnames(env_sub))
  )
  p_mat <- cor_mat

  for (i in seq_len(ncol(otu_sub))) {
    for (j in seq_len(ncol(env_sub))) {
      x <- otu_sub[, i]
      y <- env_sub[, j]
      if (sd(x)==0 || sd(y)==0) next
      test <- suppressWarnings(cor.test(x, y, method="spearman"))
      cor_mat[i, j] <- test$estimate
      p_mat[i, j] <- test$p.value
    }
  }

  list(cor=cor_mat, p=p_mat)
}

spring_res <- cor_env_indicator(spring_otus, "Spring")
summer_res <- cor_env_indicator(summer_otus, "Summer")

###########################################################
# 7. Reshape output for heatmap
###########################################################
prepare_plot_data <- function(otus, season_name) {
  otu_rel %>%
    tibble::rownames_to_column("SampleID") %>%
    pivot_longer(-SampleID, names_to="OTU", values_to="Abundance") %>%
    filter(OTU %in% otus) %>%
    left_join(group_info_ss, by="SampleID") %>%
    filter(Season == season_name) %>%
    group_by(OTU) %>%
    summarise(MeanAbundance = mean(Abundance), .groups="drop") %>%
    left_join(taxonomy_filt, by="OTU") %>%
    filter(!is.na(Family)) %>%
    mutate(
      Label = coalesce(
        Species,
        ifelse(!is.na(Genus), paste("Genus:", Genus),
        ifelse(!is.na(Family), paste("Family:", Family), OTU))
      ),
      Season = season_name
    )
}

spring_data <- prepare_plot_data(spring_otus, "Spring")
summer_data <- prepare_plot_data(summer_otus, "Summer")

reshape_correlation_data <- function(cor_list, plot_data, season_name) {
  cor_df <- as.data.frame(as.table(cor_list$cor)) %>%
    rename(OTU=Var1, EnvFactor=Var2, Correlation=Freq)

  p_df <- as.data.frame(as.table(cor_list$p)) %>%
    rename(OTU=Var1, EnvFactor=Var2, Pvalue=Freq)

  left_join(cor_df, p_df, by=c("OTU","EnvFactor")) %>%
    left_join(plot_data %>% select(OTU, MeanAbundance, Label), by="OTU") %>%
    mutate(
      Season = season_name,
      Significance = ifelse(Pvalue < 0.05, "p < 0.05", "n.s.")
    ) %>%
    filter(!is.na(Label))
}

spring_plot_df <- reshape_correlation_data(spring_res, spring_data, "Spring")
summer_plot_df <- reshape_correlation_data(summer_res, summer_data, "Summer")

plot_df_all <- bind_rows(spring_plot_df, summer_plot_df)

###########################################################
# 8. Heatmap
###########################################################
plot_df_all <- plot_df_all %>%
  mutate(
    Label_abund = paste0(Label, " (", round(MeanAbundance, 4), ")")
  )

plot_df_all$Label_abund <- factor(
  plot_df_all$Label_abund,
  levels = plot_df_all %>%
    group_by(Label_abund) %>%
    summarise(MeanAbundance = mean(MeanAbundance)) %>%
    arrange(desc(MeanAbundance)) %>%
    pull(Label_abund)
)

plot_df_all$EnvFactor <- factor(plot_df_all$EnvFactor, levels = unique(plot_df_all$EnvFactor))

p <- ggplot(
  plot_df_all,
  aes(x = EnvFactor, y = Label_abund, fill = Correlation)
) +
  geom_tile(aes(alpha = ifelse(Pvalue < 0.05, 1, 0.5)), color = "white") +
  scale_fill_gradient2(low="blue", mid="white", high="red", midpoint=0) +
  scale_alpha_identity() +
  facet_wrap(~Season, ncol=1, scales="free_y") +
  theme_minimal(base_size=12) +
  theme(
    axis.text.x = element_text(angle=45, hjust=1),
    axis.title.x = element_blank(),
    axis.ticks.x = element_blank(),
    panel.grid = element_blank(),
    strip.text = element_text(size=12, face="bold"),
    legend.position = "right"
  ) +
  labs(
    y = "Indicator Species (Mean Abundance)",
    fill = "Spearman\nCorrelation"
  )

ggsave("Example_Indicator_Heatmap.png",
       plot=p, width=8, height=8, dpi=300, units="in")
