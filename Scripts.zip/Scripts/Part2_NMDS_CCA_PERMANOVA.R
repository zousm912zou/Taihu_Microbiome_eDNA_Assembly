############################################################
# Script for Figure 2 and Figure S5
# Using example input files:
#   ASV.csv, ENV.csv, Group.csv, JWD.csv, Taxonomy.csv
#
# This script reproduces:
#   1. NMDS ordination (Bray–Curtis, with outlier removal)
#   2. Environmental fitting (envfit)
#   3. CCA constrained ordination
#   4. PERMANOVA and Betadisper
#   5. Bray–Curtis distance boxplots with PERMANOVA annotation
############################################################

library(vegan)
library(ggplot2)
library(dplyr)
library(ggforce)
library(writexl)
library(reshape2)
library(ggpubr)
library(RColorBrewer)

############################################################
# 1. Load input data
############################################################

otu <- read.csv("ASV.csv", row.names = 1, check.names = FALSE)
group_info <- read.csv("Group.csv", stringsAsFactors = FALSE)
rownames(group_info) <- group_info$Sample
env_factors <- read.csv("ENV.csv", row.names = 1, check.names = FALSE)

# Original filtering (unchanged)
otu <- otu[rowSums(otu) > 0, ]
otu <- otu[, colSums(otu) > 10]
otu <- otu[rowSums(otu) > 0, ]
otu <- otu[complete.cases(otu), ]

# Align samples across datasets
common_samples <- Reduce(intersect,
                         list(rownames(otu),
                              rownames(group_info),
                              rownames(env_factors)))

otu         <- otu[common_samples, , drop = FALSE]
group_info  <- group_info[common_samples, , drop = FALSE]
env_factors <- env_factors[common_samples, , drop = FALSE]

# Hellinger transform
otu_hel <- decostand(otu, method = "hellinger")

############################################################
# 2. NMDS
############################################################

set.seed(123)
nmds <- metaMDS(otu_hel, distance = "bray", k = 3, trymax = 500)

nmds_df <- data.frame(
  MDS1 = nmds$points[, 1],
  MDS2 = nmds$points[, 2],
  Sample = rownames(nmds$points)
) %>%
  left_join(group_info[, c("Sample", "Season", "Region")], by = "Sample")

# Outlier removal (unchanged)
IQR_MDS1 <- IQR(nmds_df$MDS1)
IQR_MDS2 <- IQR(nmds_df$MDS2)

upper_MDS1 <- quantile(nmds_df$MDS1, 0.75) + 1.5 * IQR_MDS1
lower_MDS1 <- quantile(nmds_df$MDS1, 0.25) - 1.5 * IQR_MDS1
upper_MDS2 <- quantile(nmds_df$MDS2, 0.75) + 1.5 * IQR_MDS2
lower_MDS2 <- quantile(nmds_df$MDS2, 0.25) - 1.5 * IQR_MDS2

nmds_df <- nmds_df %>%
  filter(MDS1 <= upper_MDS1, MDS1 >= lower_MDS1,
         MDS2 <= upper_MDS2, MDS2 >= lower_MDS2)

############################################################
# 3. Environmental fitting (envfit)
############################################################

env_fit <- envfit(nmds, env_factors, permutations = 100, na.rm = TRUE)

sig_env <- data.frame(
  EnvFactor = names(env_fit$vectors$pvals)[env_fit$vectors$pvals < 0.05],
  p = env_fit$vectors$pvals[env_fit$vectors$pvals < 0.05]
)

env_arrows <- as.data.frame(scores(env_fit, "vectors"))[sig_env$EnvFactor, ] * 1.2
env_arrows$EnvFactor <- rownames(env_arrows)

############################################################
# 4. CCA ordination
############################################################

cca_model <- cca(otu_hel ~ ., data = env_factors)

set.seed(123)
sig_axis    <- anova(cca_model, by = "axis", permutations = 100)
sig_overall <- anova(cca_model, permutations = 100)

imp <- summary(cca_model)$cont$importance
CCA1_perc <- round(imp[2, 1] * 100, 1)
CCA2_perc <- round(imp[2, 2] * 100, 1)

cca_scores <- scores(cca_model, display = c("sites", "bp"), scaling = 2)

cca_points <- data.frame(
  CCA1 = cca_scores$sites[, 1],
  CCA2 = cca_scores$sites[, 2],
  Sample = rownames(cca_scores$sites)
) %>%
  left_join(group_info, by = "Sample")

cca_arrows <- data.frame(
  CCA1 = cca_scores$biplot[, 1],
  CCA2 = cca_scores$biplot[, 2],
  EnvFactor = rownames(cca_scores$biplot)
)

############################################################
# 5. Plot NMDS
############################################################

nmds_plot <- ggplot(nmds_df, aes(MDS1, MDS2)) +
  geom_point(aes(color = Season, shape = Region), size = 4, alpha = 0.8) +
  ggforce::geom_mark_ellipse(aes(fill = Season), alpha = 0.2) +
  scale_color_manual(values = c("Spring" = "#4DAF4A",
                                "Summer" = "#377EB8")) +
  scale_fill_manual(values  = c("Spring" = "#4DAF4A",
                                "Summer" = "#377EB8")) +
  theme_bw(base_size = 14) +
  labs(
    title = "NMDS Ordination",
    subtitle = paste("Stress =", round(nmds$stress, 3))
  )

ggsave("Example_NMDS.png", nmds_plot, width = 8, height = 6, dpi = 300)

############################################################
# 6. Plot CCA
############################################################

cca_plot <- ggplot(cca_points, aes(CCA1, CCA2)) +
  geom_point(aes(color = Season, shape = Region), size = 4, alpha = 0.8) +
  geom_segment(
    data = cca_arrows,
    aes(x = 0, y = 0, xend = CCA1, yend = CCA2),
    arrow = arrow(length = unit(0.2, "cm")),
    linewidth = 0.7,
    color = "red"
  ) +
  geom_text(
    data = cca_arrows,
    aes(x = CCA1 * 1.12, y = CCA2 * 1.12, label = EnvFactor),
    size = 4,
    color = "red"
  ) +
  scale_color_manual(values = c("Spring" = "#4DAF4A",
                                "Summer" = "#377EB8")) +
  theme_bw(base_size = 14) +
  labs(
    title = "CCA Ordination",
    x = paste0("CCA1 (", CCA1_perc, "%)"),
    y = paste0("CCA2 (", CCA2_perc, "%)")
  )

ggsave("Example_CCA.png", cca_plot, width = 8, height = 6, dpi = 300)

############################################################
# 7. Export ordination results
############################################################

results_list <- list(
  NMDS = nmds_df,
  Envfit = cbind(env_arrows, p_value = sig_env$p),
  CCA_Importance = as.data.frame(imp),
  CCA_Significance = rbind(
    data.frame(Test = "CCA Axes", sig_axis),
    data.frame(Test = "CCA Overall", sig_overall)
  )
)

write_xlsx(results_list, "Example_Ordination_Results.xlsx")

############################################################
# 8. PERMANOVA and Betadisper
############################################################

otu_rel <- sweep(otu, 1, rowSums(otu), "/")
otu_rel[is.na(otu_rel)] <- 0

bray <- vegdist(otu_rel, method = "bray")

permanova_season <- adonis2(bray ~ Season, data = group_info, permutations = 9999)
permanova_region <- adonis2(bray ~ Region, data = group_info, permutations = 9999)
permanova_inter  <- adonis2(bray ~ Season * Region, data = group_info, permutations = 9999)

write.csv(as.data.frame(permanova_season), "Example_PERMANOVA_Season.csv")
write.csv(as.data.frame(permanova_region), "Example_PERMANOVA_Region.csv")
write.csv(as.data.frame(permanova_inter),  "Example_PERMANOVA_SeasonRegion.csv")

# Betadisper
bd_season <- betadisper(bray, group_info$Season)
bd_region <- betadisper(bray, group_info$Region)

write.csv(data.frame(ANOVA = anova(bd_season)), "Example_Betadisper_Season.csv")
write.csv(data.frame(ANOVA = anova(bd_region)), "Example_Betadisper_Region.csv")

############################################################
# 9. Bray–Curtis distance boxplot
############################################################

bray_matrix <- as.matrix(bray)
season_vec <- group_info$Season
names(season_vec) <- rownames(group_info)

distance_df <- data.frame(
  Sample1 = character(),
  Sample2 = character(),
  Distance = numeric(),
  Group = character()
)

samples <- rownames(bray_matrix)

for (i in 1:(length(samples) - 1)) {
  for (j in (i + 1):length(samples)) {
    s1 <- samples[i]
    s2 <- samples[j]
    d  <- bray_matrix[s1, s2]
    g1 <- season_vec[s1]
    g2 <- season_vec[s2]
    type <- ifelse(g1 == g2, paste0(g1, "-", g2), "Spring-Summer")
    distance_df <- rbind(distance_df,
                         data.frame(Sample1 = s1,
                                    Sample2 = s2,
                                    Distance = d,
                                    Group = type))
  }
}

distance_df$Group <- factor(distance_df$Group,
  levels = c("Spring-Spring", "Summer-Summer", "Spring-Summer")
)

R2_season <- permanova_season$R2[1]
p_season  <- permanova_season$`Pr(>F)`[1]
p_label   <- ifelse(p_season < 0.001,
                    "p < 0.001",
                    paste0("p = ", signif(p_season, 2)))

annot_label <- paste0("R² = ", round(R2_season, 3), ", ", p_label)
y_pos <- max(distance_df$Distance) * 1.05

p_bc <- ggplot(distance_df, aes(Group, Distance, fill = Group)) +
  geom_boxplot(alpha = 0.7) +
  geom_jitter(aes(color = Group), width = 0.2, alpha = 0.3, size = 1) +
  stat_compare_means(
    method = "wilcox.test",
    comparisons = list(c("Spring-Spring", "Spring-Summer"),
                       c("Summer-Summer", "Spring-Summer")),
    label = "p.signif", size = 5
  ) +
  geom_text(aes(x = 2, y = y_pos, label = annot_label), size = 5) +
  labs(y = "Bray–Curtis Distance", x = "") +
  theme_minimal(base_size = 18) +
  scale_fill_brewer(palette = "Set2") +
  scale_color_brewer(palette = "Set2")

ggsave("Example_BrayCurtis_Boxplot.png",
       p_bc, width = 8, height = 10, dpi = 300)
