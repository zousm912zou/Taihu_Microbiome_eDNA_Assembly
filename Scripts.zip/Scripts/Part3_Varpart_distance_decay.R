###########################################################
# This script reproduces Figure 3, Figure 4 and Figure S6 
# panels for a single microbial group using example input:
#   ASV.csv, ENV.csv, Group.csv, JWD.csv, Taxonomy.csv
#
# Outputs:
#   (1) β-diversity / turnover partitioning
#   (2) Variation partitioning (dumbbell + stacked barplot)
#   (3) Distance–decay by season
###########################################################


###########################################################
# Part 1 — β-diversity Partitioning
#
# Outputs:
#   Example_region_within_season.png
#   Example_turnover_within_vs_cross.png
#   Example_cross_season_Partition.png
###########################################################

suppressPackageStartupMessages({
  library(tidyverse)
  library(betaPart)
  library(vegan)
  library(ggpubr)
  library(rstatix)
})

#=====================#
# 1. Load data
#=====================#

otu_raw  <- read.csv("ASV.csv",  check.names = FALSE)
meta_raw <- read.csv("Group.csv", check.names = FALSE)

otu_id_col  <- names(otu_raw)[1]
meta_id_col <- names(meta_raw)[1]

common_samples <- intersect(otu_raw[[otu_id_col]], meta_raw[[meta_id_col]])

otu_f  <- otu_raw  |> filter(.data[[otu_id_col]] %in% common_samples)
meta_f <- meta_raw |> filter(.data[[meta_id_col]] %in% common_samples)

rownames(otu_f)  <- otu_f[[otu_id_col]]
rownames(meta_f) <- meta_f[[meta_id_col]]
otu_f <- otu_f[, setdiff(names(otu_f), otu_id_col), drop = FALSE]

otu_f  <- otu_f[rowSums(otu_f) > 0, , drop = FALSE]
otu_f  <- otu_f[, colSums(otu_f) > 0, drop = FALSE]
meta_f <- meta_f[rownames(otu_f), , drop = FALSE]

season_col <- names(meta_f)[2]
region_col <- names(meta_f)[3]

meta_min <- meta_f %>%
  select(Season = all_of(season_col),
         Region = all_of(region_col)) %>%
  mutate(SampleID = rownames(meta_f)) %>%
  mutate(Season = factor(Season, levels = c("Spring","Summer")))


#=====================#
# 2. Relative abundance
#=====================#

otu_rel <- decostand(otu_f, method = "total", MARGIN = 1)


#=====================#
# 3. β-diversity Partitioning
#=====================#

beta_pair <- beta.pair.abund(as.matrix(otu_rel))

as_pairs <- function(mat, comp){
  m <- as.matrix(mat); m[lower.tri(m, diag = TRUE)] <- NA
  as.data.frame(as.table(m)) %>%
    filter(!is.na(Freq)) %>%
    rename(Sample1 = Var1, Sample2 = Var2, value = Freq) %>%
    mutate(component = comp)
}

df_bal <- as_pairs(beta_pair$beta.bray.bal, "beta_bal")
df_gra <- as_pairs(beta_pair$beta.bray.gra, "beta_gra")
df_tot <- as_pairs(beta_pair$beta.bray,     "beta_tot")

beta_long <- bind_rows(df_bal, df_gra, df_tot)

beta_annot <- beta_long %>%
  left_join(meta_min %>% rename(Sample1 = SampleID,
                                Season1 = Season, Region1 = Region),
            by = "Sample1") %>%
  left_join(meta_min %>% rename(Sample2 = SampleID,
                                Season2 = Season, Region2 = Region),
            by = "Sample2")


#=====================#
# 4. Within-season vs cross-season
#=====================#

beta_within <- beta_annot %>% filter(Season1 == Season2)
beta_cross  <- beta_annot %>% filter(Season1 != Season2)

region_df <- beta_within %>%
  filter(component %in% c("beta_bal","beta_gra")) %>%
  mutate(
    Season = Season1,
    same_region = if_else(Region1 == Region2, "SameRegion","DifferentRegion"),
    component = recode(component,
                       beta_bal = "Turnover (β_bal)",
                       beta_gra = "Abundance gradient (β_gra)")
  ) %>%
  select(Season, component, same_region, value)


#=====================#
# 5. Spatial stats
#=====================#

safe_wilcox <- function(df){
  g <- table(df$same_region)
  if (length(g) < 2 || any(g==0)) return(NA)
  if (sd(df$value)==0) return(NA)
  wt <- suppressWarnings(wilcox.test(value ~ same_region, data=df))
  wt$p.value
}

region_stats <- region_df %>%
  group_by(Season, component) %>%
  summarise(p = safe_wilcox(cur_data()), .groups="drop") %>%
  mutate(
    p_adj = p.adjust(p, method="BH"),
    label = case_when(
      p_adj < 0.001 ~ "***",
      p_adj < 0.01  ~ "**",
      p_adj < 0.05  ~ "*",
      TRUE          ~ "ns"
    )
  )

ypos <- region_df %>% group_by(Season, component) %>% summarise(y=max(value),.groups="drop")

ann <- left_join(region_stats, ypos, by=c("Season","component")) %>%
  mutate(group1="SameRegion", group2="DifferentRegion", y.position = y*1.05)


#=====================#
# 6A. Plot: Within-season spatial effect
#=====================#

p_region <- ggplot(region_df, aes(same_region, value, fill=same_region)) +
  geom_boxplot(width=0.6) +
  facet_grid(component ~ Season, scales="free_y") +
  stat_pvalue_manual(ann, label="label", y.position="y.position",
                     tip.length=0) +
  labs(title="Within-season spatial effect (Same vs Different Region)",
       y="Bray–Curtis component", x=NULL) +
  theme_bw() +
  theme(legend.position="none")

ggsave("Example_region_within_season.png",
       p_region, width=7.2, height=4.5, dpi=600)


#=====================#
# 6B. Plot: Turnover within vs cross-season
#=====================#

cmp_df <- bind_rows(
  beta_within %>% filter(component=="beta_bal") %>%
    mutate(group="Within-season") %>% mutate(Season=Season1),
  beta_cross %>% filter(component=="beta_bal") %>%
    mutate(group="Cross-season")
)

p_cmp <- ggplot(cmp_df, aes(group, value, fill=group)) +
  geom_boxplot(width=0.6) +
  stat_compare_means(method="wilcox.test",
                     label="p.signif", hide.ns=TRUE) +
  labs(title="Turnover: within-season vs cross-season",
       y="Turnover (β_bal)", x=NULL) +
  theme_bw()

ggsave("Example_turnover_within_vs_cross.png",
       p_cmp, width=5.0, height=3.5, dpi=600)


#=====================#
# 6C. Plot: Cross-season partitioning
#=====================#

cross_df <- beta_cross %>%
  filter(component %in% c("beta_bal","beta_gra")) %>%
  mutate(component = recode(component,
                            beta_bal="Turnover (β_bal)",
                            beta_gra="Abundance gradient (β_gra)"))

p_cross <- ggplot(cross_df, aes(component, value, fill=component)) +
  geom_boxplot(width=0.6) +
  labs(title="Cross-season β-diversity Partitioning (Spring–Summer)",
       y="Bray–Curtis component", x=NULL) +
  theme_bw()

ggsave("Example_cross_season_Partition.png",
       p_cross, width=5.0, height=3.5, dpi=600)



###########################################################
# Part 2 — Variation Partitioning
#
# Outputs:
#   Example_VarPart_Dumbbell.png
#   Example_VarPart_StackedBarplot.png
###########################################################

pkgs <- c("vegan","adespatial","sf","igraph","dplyr","tidyr",
          "ggplot2","readr","scales","patchwork","tibble",
          "geosphere","reshape2")
ins  <- pkgs[!pkgs %in% installed.packages()[,1]]
if(length(ins)) install.packages(ins)
invisible(lapply(pkgs, library, character.only=TRUE))


#====================#
# 1. Read data
#====================#

env <- read.csv("ENV.csv", check.names=FALSE)
grp <- read.csv("Group.csv", check.names=TRUE)
jwd <- read.csv("JWD.csv", check.names=FALSE)
otu <- read.csv("ASV.csv", check.names=FALSE)

names(jwd) <- trimws(names(jwd))
if("Samples"    %in% names(jwd)) jwd <- rename(jwd, Sample=Samples)
if(" Latitude"  %in% names(jwd)) jwd <- rename(jwd, Latitude=` Latitude`)
if(" Longitude" %in% names(jwd)) jwd <- rename(jwd, Longitude=` Longitude`)

stopifnot(all(c("Sample","Latitude","Longitude") %in% names(jwd)))
stopifnot(all(c("Sample","Season") %in% names(grp)))
stopifnot("Sample" %in% names(env))
stopifnot("Sample" %in% names(otu))


#====================#
# 2. Clean coords
#====================#

clean_num <- function(x){
  x <- as.character(x); x <- trimws(x)
  x <- gsub(",", ".", x)
  x <- gsub("[^0-9+\\-\\.]", "", x)
  suppressWarnings(as.numeric(x))
}

jwd$Longitude <- clean_num(jwd$Longitude)
jwd$Latitude  <- clean_num(jwd$Latitude)
jwd <- filter(jwd, is.finite(Longitude), is.finite(Latitude))


#====================#
# 3. Function: varPart
#====================#

run_one_group_from_df <- function(otu_df, group_label="ASV"){

  stopifnot("Sample" %in% names(otu_df))

  common <- Reduce(intersect,
                   list(otu_df$Sample, env$Sample, grp$Sample, jwd$Sample))

  otu1 <- filter(otu_df, Sample %in% common)
  env1 <- filter(env,    Sample %in% common)
  grp1 <- filter(grp,    Sample %in% common)
  jwd1 <- filter(jwd,    Sample %in% common)

  rownames(otu1) <- otu1$Sample
  rownames(env1) <- env1$Sample

  Y <- otu1[, setdiff(names(otu1),"Sample"), drop=FALSE]
  Y <- decostand(decostand(Y,"total"), "hellinger")

  E <- env1[, setdiff(names(env1),"Sample"),drop=FALSE]
  E <- E[,sapply(E,is.numeric),drop=FALSE]
  E <- scale(E) |> as.data.frame()

  common2 <- Reduce(intersect,
                    list(rownames(Y), rownames(E), grp1$Sample, jwd1$Sample))

  Y    <- Y[common2,,drop=FALSE]
  E    <- E[common2,,drop=FALSE]
  grp1 <- grp1[grp1$Sample %in% common2,]
  jwd1 <- jwd1[jwd1$Sample %in% common2,]

  rownames(jwd1) <- jwd1$Sample
  pts <- st_as_sf(jwd1, coords=c("Longitude","Latitude"), crs=4326)
  mean_lon <- mean(st_coordinates(pts)[,1])
  zone     <- floor((mean_lon+180)/6)+1
  crs_utm  <- paste0("+proj=utm +zone=",zone," +datum=WGS84 +units=m")
  pts      <- st_transform(pts, crs_utm)

  coords_m <- st_coordinates(pts)
  Dmat <- as.matrix(dist(coords_m))
  g    <- graph_from_adjacency_matrix(Dmat, weighted=TRUE,
                                      mode="undirected", diag=FALSE)
  mst    <- mst(g)
  thresh <- max(E(mst)$weight)

  S <- tryCatch(
    dbmem(coords_m, thresh=thresh, silent=TRUE),
    error=function(e) pcnm(as.dist(coords_m))$vectors
  )

  S <- as.data.frame(S)
  rownames(S) <- rownames(Y)
  S <- S[, sapply(S,var)>0, drop=FALSE]

  do_one <- function(sea){
    ids <- grp1$Sample[grp1$Season==sea]
    ids <- intersect(ids, rownames(Y))
    if(length(ids) < 6) return(NULL)

    Y2 <- Y[ids,,drop=FALSE]
    E2 <- E[ids,,drop=FALSE]
    S2 <- S[ids,,drop=FALSE]

    mod_all   <- rda(Y2 ~ ., data=cbind(E2,S2))
    adj_total <- RsquareAdj(mod_all)$adj.r.squared

    mod_E <- rda(Y2, E2, S2)
    mod_S <- rda(Y2, S2, E2)

    adj_E <- RsquareAdj(mod_E)$adj.r.squared
    adj_S <- RsquareAdj(mod_S)$adj.r.squared

    shared <- max(0, adj_E + adj_S - adj_total)
    pureE  <- max(0, adj_E - shared)
    pureS  <- max(0, adj_S - shared)
    unexp  <- max(0, 1 - adj_total)

    tibble(
      Group       = group_label,
      Season      = sea,
      Pure_env    = pureE,
      Pure_space  = pureS,
      Shared      = shared,
      Unexplained = unexp
    )
  }

  bind_rows(do_one("Spring"), do_one("Summer"))
}

res_asv <- run_one_group_from_df(otu, "ASV")
print(res_asv)


###########################################################
# 4. Dumbbell plot 
###########################################################

plot_dumbbell <- function(df, title="(A) ASV"){
  xmax <- max(df$Pure_env, df$Pure_space)*1.15
  ggplot(df, aes(y=Season)) +
    geom_segment(aes(x=Pure_space, xend=Pure_env, yend=Season),
                 color="#bfc5c9", linewidth=1.2) +
    geom_point(aes(x=Pure_env),  color="#2E948A", size=4) +
    geom_point(aes(x=Pure_space), color="#F39C12", size=4) +
    geom_text(aes(x=Pure_env+0.005, label=scales::percent(Pure_env)),
              color="#2E948A", hjust=0, size=4) +
    geom_text(aes(x=Pure_space-0.005, label=scales::percent(Pure_space)),
              color="#F39C12", hjust=1, size=4) +
    scale_x_continuous(labels=scales::percent, limits=c(0,xmax)) +
    labs(title=title, x="Adjusted R²", y=NULL) +
    theme_classic(base_size=14)
}

p_dumbbell <- plot_dumbbell(res_asv, "(A) ASV")

ggsave("Example_VarPart_Dumbbell.png",
       p_dumbbell, width=6, height=4, dpi=600)


###########################################################
# 5. Stacked barplot
###########################################################

fill_cols <- c(
  "Pure environment" = "#2E948A",
  "Shared E∩S"       = "#A6ACB3",
  "Pure space"       = "#F39C12",
  "Unexplained"      = "#E9ECEF"
)

dfL <- res_asv %>%
  transmute(
    Season,
    `Pure environment` = Pure_env,
    `Pure space`       = Pure_space,
    `Shared E∩S`       = Shared,
    `Unexplained`      = Unexplained
  ) %>%
  pivot_longer(-Season, names_to="fraction", values_to="adjR2") %>%
  mutate(fraction = factor(
    fraction,
    levels=c("Unexplained","Pure space","Shared E∩S","Pure environment")
  ))

lab_df <- dfL %>% filter(fraction=="Unexplained") %>%
  mutate(label=scales::percent(adjR2,accuracy=1))

p_stack <- ggplot(dfL, aes(Season, adjR2, fill=fraction)) +
  geom_col(width=0.7, color="white", linewidth=0.25) +
  geom_text(data=lab_df, aes(label=label),
            vjust=0.5, color="black", size=3.8) +
  scale_y_continuous(labels=scales::percent_format(accuracy=10), limits=c(0,1)) +
  scale_fill_manual(values=fill_cols, name=NULL) +
  labs(title="(B) Variation Partitioning — ASV",
       x=NULL, y="Adjusted R²") +
  theme_classic(base_size=14) +
  theme(legend.position="top",
        plot.title=element_text(face="bold"))

ggsave("Example_VarPart_StackedBarplot.png",
       p_stack, width=6.5, height=5, dpi=600)



###########################################################
# Part 3 — Distance–Decay
#
# Output:
#   Example_distance_decay_by_season.png
###########################################################

pkgs <- c("vegan","geosphere","dplyr","ggplot2")
ins  <- pkgs[!pkgs %in% installed.packages()[,1]]
if(length(ins)) install.packages(ins)
invisible(lapply(pkgs, library, character.only=TRUE))


############################################################
# 1. Load data
############################################################

ASV  <- read.csv("ASV.csv",  row.names=1, check.names=FALSE)
meta <- read.csv("JWD.csv",  row.names=1, check.names=FALSE)

stopifnot(all(c("Season","Latitude","Longitude") %in% names(meta)))


############################################################
# 2. Normalize Season names
############################################################

meta$Season <- as.character(meta$Season)
meta$Season[meta$Season=="April"] <- "Spring"
meta$Season <- factor(meta$Season)


############################################################
# 3. Clean ASV table
############################################################

ASV <- ASV[rowSums(ASV)>0,]
ASV <- ASV[,colSums(ASV)>10]
ASV <- ASV[rowSums(ASV)>0,]
ASV <- ASV[complete.cases(ASV),]


############################################################
# 4. Clean coordinates
############################################################

meta$Longitude[meta$Longitude==""] <- NA
meta$Latitude[meta$Latitude==""]  <- NA

meta$Longitude <- as.numeric(as.character(meta$Longitude))
meta$Latitude  <- as.numeric(as.character(meta$Latitude))

meta <- meta[!is.na(meta$Longitude) & !is.na(meta$Latitude),]


############################################################
# 5. Align samples
############################################################

common <- intersect(rownames(ASV), rownames(meta))
ASV  <- ASV[common,]
meta <- meta[common,]


############################################################
# 6. Relative abundance
############################################################

ASV_rel <- ASV / rowSums(ASV)
ASV_rel <- as.data.frame(ASV_rel)


############################################################
# 7. Function: single-season decay
############################################################

distance_decay_one <- function(season_name){

  ids <- rownames(meta)[meta$Season==season_name]
  if(length(ids)<3){
    message("⚠ Season ", season_name, " has fewer than 3 samples, skipping")
    return(NULL)
  }

  ASV_season <- ASV_rel[ids,,drop=FALSE]
  coords     <- meta[ids, c("Longitude","Latitude")]

  bc_dist  <- vegdist(ASV_season, method="bray")
  geo_dist <- distm(coords, fun=distHaversine) / 1000

  bc_mat  <- as.matrix(bc_dist)
  geo_mat <- as.matrix(geo_dist)

  bc_vec  <- bc_mat[lower.tri(bc_mat)]
  geo_vec <- geo_mat[lower.tri(geo_mat)]

  data.frame(
    Geographic_Distance  = geo_vec,
    Bray_Curtis_Distance = bc_vec,
    Season               = season_name
  )
}


############################################################
# 8. Compute Spring + Summer
############################################################

df_spring <- distance_decay_one("Spring")
df_summer <- distance_decay_one("Summer")

dfs <- list(Spring=df_spring, Summer=df_summer)
dfs <- dfs[!sapply(dfs,is.null)]

if(length(dfs)==0){
  stop("No season has enough samples for distance–decay analysis.")
}

df_all <- bind_rows(dfs)


############################################################
# 9. Fit regression + labels
############################################################

make_lm_labels <- function(df, season_label){
  fit <- lm(Bray_Curtis_Distance ~ Geographic_Distance, data=df)
  eq  <- paste0(
    season_label, ": y = ",
    round(coef(fit)[2],3), "x + ", round(coef(fit)[1],3)
  )
  r2p <- paste0(
    season_label, ": R² = ",
    round(summary(fit)$r.squared,3),
    ", p = ", signif(summary(fit)$coefficients[2,4],3)
  )
  list(eq=eq, r2p=r2p)
}

season_levels <- unique(df_all$Season)

labs_list <- lapply(season_levels, function(sea){
  make_lm_labels(df_all[df_all$Season==sea,], sea)
})
names(labs_list) <- season_levels


############################################################
# 10. Annotation placement
############################################################

x_min <- min(df_all$Geographic_Distance)
x_max <- max(df_all$Geographic_Distance)
y_min <- min(df_all$Bray_Curtis_Distance)
y_max <- max(df_all$Bray_Curtis_Distance)

label_x      <- x_max - 0.005*(x_max-x_min)
label_y_base <- y_min + 0.05*(y_max-y_min)
line_spacing <- 0.05*(y_max-y_min)


############################################################
# 11. Build annotation tables
############################################################

k <- length(season_levels)

ann_eq <- do.call(rbind, lapply(seq_along(season_levels), function(i){
  sea <- season_levels[i]
  data.frame(
    x=label_x,
    y=label_y_base + (k+i)*line_spacing,
    label=labs_list[[sea]]$eq,
    Season=sea
  )
}))

ann_stats <- do.call(rbind, lapply(seq_along(season_levels), function(i){
  sea <- season_levels[i]
  data.frame(
    x=label_x,
    y=label_y_base + (i-1)*line_spacing,
    label=labs_list[[sea]]$r2p,
    Season=sea
  )
}))


############################################################
# 12. Plot distance–decay
############################################################

p <- ggplot(df_all,
            aes(x=Geographic_Distance,
                y=Bray_Curtis_Distance,
                color=Season)) +
  geom_point(alpha=0.5) +
  geom_smooth(method="lm", se=TRUE, size=1.2) +
  geom_text(data=ann_eq,
            aes(x=x,y=y,label=label,color=Season),
            hjust=1,vjust=0,size=6,fontface="italic",
            show.legend=FALSE) +
  geom_text(data=ann_stats,
            aes(x=x,y=y,label=label,color=Season),
            hjust=1,vjust=0,size=6,fontface="italic",
            show.legend=FALSE) +
  labs(
    title="Bacterioplankton",
    x="Geographic Distance (km)",
    y="Bray–Curtis Dissimilarity"
  ) +
  theme_minimal() +
  theme(
    text=element_text(size=14),
    plot.title=element_text(size=18,hjust=0.5),
    axis.title.x=element_text(size=18),
    axis.title.y=element_text(size=18),
    axis.text.x=element_text(size=16),
    axis.text.y=element_text(size=16),
    legend.title=element_text(size=18),
    legend.text=element_text(size=16)
  )

ggsave("Example_distance_decay_by_season.png",
       plot=p, width=8, height=6, dpi=300)
