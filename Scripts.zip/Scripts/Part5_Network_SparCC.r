############################################################
# Network_Sparcc Analysis
# Complete Script for Reproducing Figure 6-7 and Figure S8-11
###########################################################
## Step 0 — Load required R packages
###########################################################
library(SpiecEasi)
library(igraph)
library(RColorBrewer)
library(scales)
library(openxlsx)

###########################################################
## Step A — Load taxonomy table
###########################################################
tax <- read.csv("Network_taxonomy.csv", row.names = 1, check.names = FALSE)
tax$Phylum[is.na(tax$Phylum) | tax$Phylum==""] <- "unclassified"

###########################################################
## Step B — Core function: full SparCC → igraph workflow
## Returns:
##   g                = igraph object
##   top10            = top 10 phyla by degree
##   season_map       = per-season color map (before harmonization)
##   edge_list        = SparCC edge list
##   degree           = node degree vector
##   edge_weight      = edge weight vector
###########################################################
run_one_season <- function(otu_file, png_name, xlsx_name){

  ## ------------------------------
  ## 1. Load raw OTU and preprocess
  ## ------------------------------
  otu_raw <- read.csv(otu_file, row.names = 1, check.names = FALSE)
  otu_raw <- otu_raw[, colSums(otu_raw) > 0]
  otu_raw <- otu_raw[rowSums(otu_raw) > 0, ]
  otu_relative_abundance <- otu_raw / rowSums(otu_raw)
  otu_relative_abundance <- as.data.frame(lapply(otu_relative_abundance, function(x) {
    x[is.infinite(x) | is.na(x)] <- 0
    return(x)
  }))
  rownames(otu_relative_abundance) <- rownames(otu_raw)
  otu_t <- t(otu_relative_abundance) + 1e-6
  otu_t <- otu_t[apply(otu_t, 1, sd) > 1e-6, ]

  ## ------------------------------
  ## 2. Align taxonomy
  ## ------------------------------
  rownames(otu_t) <- trimws(rownames(otu_t))
  rownames(tax)   <- trimws(rownames(tax))
  common_otus <- intersect(rownames(otu_t), rownames(tax))
  otu_t_common <- otu_t[common_otus, ]
  tax_common   <- tax[common_otus, ]
  tax_common$Phylum[is.na(tax_common$Phylum) | tax_common$Phylum==""] <- "unclassified"

  ## ------------------------------
  ## 3. Phylum abundance summary
  ## ------------------------------
  otu_sum <- rowSums(otu_t_common)
  Phylum_abundance_total <- tapply(otu_sum, tax_common$Phylum, sum)
  sorted_Phyla <- names(sort(Phylum_abundance_total, decreasing = TRUE))
  cat("Total phyla:", length(sorted_Phyla), "\n")
  cat("Top 10 phyla by total abundance:\n")
  print(head(sort(Phylum_abundance_total, decreasing = TRUE), 10))

  ## ------------------------------
  ## 4–6. SparCC correlation network
  ## ------------------------------
  otu_all <- t(otu_t_common)
  sparcc_results <- sparcc(otu_all)
  sparcc_matrix  <- sparcc_results$Cor
  otu_names <- colnames(otu_all)
  rownames(sparcc_matrix) <- otu_names
  colnames(sparcc_matrix) <- otu_names

  edges <- which(abs(sparcc_matrix) >= 0.07 & upper.tri(sparcc_matrix), arr.ind = TRUE)
  edge_list <- data.frame(
    from   = rownames(sparcc_matrix)[edges[,1]],
    to     = colnames(sparcc_matrix)[edges[,2]],
    weight = sparcc_matrix[edges],
    sign   = ifelse(sparcc_matrix[edges] > 0, "positive", "negative")
  )
  cat("Edges retained:", nrow(edge_list), "\n")

  ## ------------------------------
  ## 7. Build igraph object
  ## ------------------------------
  otu_degree <- table(c(edge_list$from, edge_list$to))
  otu_degree <- as.data.frame(otu_degree)
  colnames(otu_degree) <- c("OTU","Degree")

  otu_nodes <- data.frame(
    OTU    = unique(c(edge_list$from, edge_list$to)),
    Phylum = tax_common[unique(c(edge_list$from, edge_list$to)),"Phylum"]
  )
  otu_nodes$Phylum[is.na(otu_nodes$Phylum) | otu_nodes$Phylum==""] <- "unclassified"
  otu_nodes <- merge(otu_nodes, otu_degree, by="OTU", all.x=TRUE)
  otu_nodes$Degree[is.na(otu_nodes$Degree)] <- 0

  g <- graph_from_data_frame(d = edge_list, vertices = otu_nodes, directed = FALSE)
  E(g)$weight <- abs(E(g)$weight)

  ## ------------------------------
  ## 8. Network statistics
  ## ------------------------------
  average_path_length <- tryCatch({
    mean_distance(g, directed = FALSE, weights = E(g)$weight)
  }, error = function(e){
    warning("Mean path length failed: ", conditionMessage(e))
    NA
  })

  network_density <- edge_density(g)
  transitivity_val <- transitivity(g)

  cat("Network density: ", network_density, "\n")
  cat("Mean path length: ", average_path_length, "\n")
  cat("Clustering coefficient: ", transitivity_val, "\n")

  ## ------------------------------
  ## Top-10 Phyla (by degree sum) + per-season color map
  ## ------------------------------
  Phylum_degree_sum <- tapply(V(g)$Degree, V(g)$Phylum, sum)
  top_Phylum_by_degree <- names(sort(Phylum_degree_sum, decreasing=TRUE))[1:10]
  cat("Top 10 Phyla (Degree-based):\n")
  print(top_Phylum_by_degree)

  Phylum_in_network <- unique(V(g)$Phylum)
  display_Phyla <- top_Phylum_by_degree
  other_exists <- any(!Phylum_in_network %in% c(display_Phyla,"unclassified"))

  color_count <- length(display_Phyla)
  palette_colors <- if(color_count <= 9){
    brewer.pal(max(3,color_count),"Set1")
  } else {
    colorRampPalette(brewer.pal(9,"Set1"))(color_count)
  }
  Phylum_colors <- setNames(palette_colors, display_Phyla)
  Phylum_colors["unclassified"] <- "lightgray"
  if(other_exists) Phylum_colors["Other"] <- "darkgray"

  V(g)$Phylum <- sapply(V(g)$Phylum, function(x){
    if(x=="unclassified") return("unclassified")
    if(x %in% display_Phyla) return(x)
    return("Other")
  })
  season_map <- Phylum_colors

  ## ------------------------------
  ## Return
  ## ------------------------------
  list(
    g = g,
    edge_list = edge_list,
    network_density = network_density,
    average_path_length = average_path_length,
    transitivity = transitivity_val,
    top10 = top_Phylum_by_degree,
    season_map = season_map,
    degree = degree(g),
    edge_weight = abs(E(g)$weight),
    png_name = png_name,
    xlsx_name = xlsx_name
  )
}

###########################################################
## Step C — Run for Spring & Summer
###########################################################
spring <- run_one_season("Network_ASV_Spring.csv",
                         "SparCC_OTU_Network_Spring.png",
                         "SparCC_Results_Spring_Bacterioplankton.xlsx")

summer <- run_one_season("Network_ASV_Summer.csv",
                         "SparCC_OTU_Network_Summer.png",
                         "SparCC_Results_Summer_Bacterioplankton.xlsx")

Phylum_colors_spring <- spring$season_map
Phylum_colors_summer <- summer$season_map


###########################################################
## Harmonize colors across seasons (global Top10 color map)
###########################################################
top10_spring <- spring$top10
top10_summer <- summer$top10

common_top10 <- intersect(top10_spring, top10_summer)
spring_only  <- setdiff(top10_spring, common_top10)
summer_only  <- setdiff(top10_summer, common_top10)

n_common <- length(common_top10)
n_spring <- length(spring_only)
n_summer <- length(summer_only)
total_required <- n_common + n_spring + n_summer

base_colors <- colorRampPalette(brewer.pal(9,"Set1"))(total_required)

color_map_common      <- setNames(base_colors[1:n_common], common_top10)
color_map_spring_only <- setNames(base_colors[(n_common+1):(n_common+n_spring)], spring_only)
color_map_summer_only <- setNames(base_colors[(n_common+n_spring+1):(n_common+n_spring+n_summer)], summer_only)

global_color_map <- c(
  color_map_common,
  color_map_spring_only,
  color_map_summer_only,
  "unclassified" = "lightgray",
  "Other" = "darkgray"
)

V(spring$g)$color <- global_color_map[V(spring$g)$Phylum]
V(summer$g)$color <- global_color_map[V(summer$g)$Phylum]

Phylum_colors_spring <- global_color_map[top10_spring]
Phylum_colors_summer <- global_color_map[top10_summer]

Phylum_colors_spring["unclassified"] <- "lightgray"
Phylum_colors_summer["unclassified"] <- "lightgray"

###########################################################
## Step E — Side-by-side network visualization
###########################################################
png("Example_Spring_Summer_Comparison_Bacterioplankton.png", width=7000, height=2800, res=300)

layout(matrix(c(1,2), nrow=1), widths=c(1,1))
par(oma=c(0,1,0,6), xpd=NA)

scale_node_size <- function(deg, min_size=2, max_size=8){
  scaled <- (deg - min(deg)) / (max(deg)-min(deg))
  scaled * (max_size-min_size) + min_size
}

V(spring$g)$size <- scale_node_size(V(spring$g)$Degree)
V(summer$g)$size <- scale_node_size(V(summer$g)$Degree)

### --- Spring ---
par(mar=c(3,1.5,4,0.2))
set.seed(123)
fc_s <- cluster_fast_greedy(spring$g)
V(spring$g)$module <- membership(fc_s)
module_counts_s <- sort(table(V(spring$g)$module), decreasing=TRUE)
top_modules_s <- names(module_counts_s)[1:3]
V(spring$g)$shape <- "circle"
V(spring$g)$frame.color <- ifelse(V(spring$g)$module %in% top_modules_s, "black", NA)

plot(
  spring$g,
  vertex.label = NA,
  layout = layout_with_fr,
  vertex.color = V(spring$g)$color,
  vertex.size = V(spring$g)$size,
  vertex.frame.color = V(spring$g)$frame.color,
  vertex.shape = V(spring$g)$shape,
  edge.color = E(spring$g)$color,
  edge.width = E(spring$g)$width,
  margin = -0.15
)
title("Spring (Bacterioplankton)", line=2.8, cex.main=1.6)

Phylum_colors <- Phylum_colors_spring
legend(x=1.12, y=1.00, legend=names(Phylum_colors),
       col=Phylum_colors, pch=16, pt.cex=1, bty="n",
       title="Phylum", title.font=2, cex=1.2)

legend(x=1.12, y=0.20, legend=c("Low","High"),
       lwd=c(1,5), col="gray", bty="n",
       title="Edge Strength", title.font=2, cex=1.2)

legend(x=1.12, y=-0.05, legend=c("Low","High"),
       pch=16, pt.cex=c(0.8,2), bty="n",
       title="Degree", title.font=2, cex=1.2)

legend(x=1.12, y=-0.35, legend=c("Positive","Negative"),
       col=c("steelblue","steelblue"),
       lty=c(1,2), lwd=2, bty="n",
       title="Edge Sign", title.font=2, cex=1.2)

legend(x=1.12, y=-0.60, legend="",
       pch=1, pt.cex=1.6, col="black",
       bty="n", title="Top 3 Modules", title.font=2, cex=1.2)

### --- Summer ---
par(mar=c(3,0.2,4,0.2))

set.seed(123)
fc_u <- cluster_fast_greedy(summer$g)
V(summer$g)$module <- membership(fc_u)
module_counts_u <- sort(table(V(summer$g)$module), decreasing=TRUE)
top_modules_u <- names(module_counts_u)[1:3]
V(summer$g)$shape <- "circle"
V(summer$g)$frame.color <- ifelse(V(summer$g)$module %in% top_modules_u, "black", NA)

plot(
  summer$g,
  vertex.label = NA,
  layout = layout_with_fr,
  vertex.color = V(summer$g)$color,
  vertex.size = V(summer$g)$size,
  vertex.frame.color = V(summer$g)$frame.color,
  vertex.shape = V(summer$g)$shape,
  edge.color = E(summer$g)$color,
  edge.width = E(summer$g)$width,
  margin = -0.15
)
title("Summer (Bacterioplankton)", line=2.8, cex.main=1.6)

Phylum_colors <- Phylum_colors_summer
legend(x=1.12, y=1.00, legend=names(Phylum_colors),
       col=Phylum_colors, pch=16, pt.cex=1, bty="n",
       title="Phylum", title.font=2, cex=1.2)

legend(x=1.12, y=0.20, legend=c("Low","High"),
       lwd=c(1,5), col="gray", bty="n",
       title="Edge Strength", title.font=2, cex=1.2)

legend(x=1.12, y=-0.05, legend=c("Low","High"),
       pch=16, pt.cex=c(0.8,2), bty="n",
       title="Degree", title.font=2, cex=1.2)

legend(x=1.12, y=-0.35, legend=c("Positive","Negative"),
       col=c("steelblue","steelblue"),
       lty=c(1,2), lwd=2, bty="n",
       title="Edge Sign", title.font=2, cex=1.2)

legend(x=1.12, y=-0.60, legend="",
       pch=1, pt.cex=1.6, col="black",
       bty="n", title="Top 3 Modules", title.font=2, cex=1.2)

dev.off()
cat("\n✔ Combined network figure saved: Example_Spring_Summer_Comparison_Bacterioplankton.png\n")


###########################################################
## Step F — Export Excel for each season
###########################################################
# Spring
wb1 <- createWorkbook()
addWorksheet(wb1, "SparCC Results")
writeData(wb1, "SparCC Results", spring$edge_list)
addWorksheet(wb1, "Network Stats")
writeData(wb1, "Network Stats", data.frame(
  Network_Density = spring$network_density,
  Average_Path_Length = spring$average_path_length,
  Transitivity = spring$transitivity
))
saveWorkbook(wb1, "SparCC_Results_Spring.xlsx", overwrite=TRUE)

# Summer
wb2 <- createWorkbook()
addWorksheet(wb2, "SparCC Results")
writeData(wb2, "SparCC Results", summer$edge_list)
addWorksheet(wb2, "Network Stats")
writeData(wb2, "Network Stats", data.frame(
  Network_Density = summer$network_density,
  Average_Path_Length = summer$average_path_length,
  Transitivity = summer$transitivity
))
saveWorkbook(wb2, "SparCC_Results_Summer.xlsx", overwrite=TRUE)


###########################################################
## Step F-2 — Robustness Analysis
###########################################################
library(pracma)

compute_robustness <- function(g){
  g_work <- g
  n <- vcount(g_work)
  largest_comp <- numeric(n+1)

  for(i in 0:n){
    if(vcount(g_work) > 0){
      comps <- components(g_work)
      largest_comp[i+1] <- max(comps$csize) / n
    } else {
      largest_comp[i+1] <- 0
    }
    if(i < n){
      g_work <- delete_vertices(g_work, which.max(degree(g_work)))
    }
  }

  robustness_df <- data.frame(
    Fraction_Removed = 0:n / n,
    Fraction_Remaining = largest_comp
  )

  robustness_auc <- trapz(robustness_df$Fraction_Removed,
                          robustness_df$Fraction_Remaining)

  return(list(df=robustness_df, auc=robustness_auc))
}

spring_res <- compute_robustness(spring$g)
summer_res <- compute_robustness(summer$g)

rob_spring <- spring_res$auc
rob_summer <- summer_res$auc

spring_res$df$Season <- "Spring"
summer_res$df$Season <- "Summer"
robustness_df <- rbind(spring_res$df, summer_res$df)

cat("\n✔ Robustness computed (AUC): Spring =", rob_spring,
    "| Summer =", rob_summer, "\n")


###########################################################
## Step G — Figure 6: Network Summary Comparison
###########################################################
library(openxlsx)

add_distributions_to_metrics <- function(metrics_file, spring_obj, summer_obj, GroupName){

  metrics_df <- read.xlsx(metrics_file)

  deg_s <- data.frame(Metric="Degree", Season="Spring",
                      Value=spring_obj$degree)

  deg_u <- data.frame(Metric="Degree", Season="Summer",
                      Value=summer_obj$degree)

  w_s <- data.frame(Metric="EdgeStrength", Season="Spring",
                    Value=spring_obj$edge_weight)

  w_u <- data.frame(Metric="EdgeStrength", Season="Summer",
                    Value=summer_obj$edge_weight)

  dist_df <- rbind(deg_s, deg_u, w_s, w_u)
  dist_df$Group <- GroupName

  wb <- loadWorkbook(metrics_file)
  addWorksheet(wb, "Distributions")
  writeData(wb, "Distributions", dist_df)
  saveWorkbook(wb, metrics_file, overwrite=TRUE)

  cat("✔ Distributions appended to", metrics_file, "\n")
}

fc_s <- cluster_fast_greedy(spring$g)
fc_u <- cluster_fast_greedy(summer$g)

node_count_spring <- vcount(spring$g)
node_count_summer <- vcount(summer$g)

module_count_spring <- length(table(membership(fc_s)))
module_count_summer <- length(table(membership(fc_u)))

edge_count_spring <- nrow(spring$edge_list)
edge_count_summer <- nrow(summer$edge_list)

pos_spring <- sum(spring$edge_list$sign=="positive") / edge_count_spring
pos_summer <- sum(summer$edge_list$sign=="positive") / edge_count_summer
neg_spring <- 1 - pos_spring
neg_summer <- 1 - pos_summer

mod_spring <- spring$transitivity
mod_summer <- summer$transitivity

metrics_df <- data.frame(
  Metric = c("Node Count","Module Count","Edge Count",
             "Positive %","Transitivity","Robustness (AUC)"),
  Spring = c(node_count_spring, module_count_spring, edge_count_spring,
             pos_spring, mod_spring, rob_spring),
  Summer = c(node_count_summer, module_count_summer, edge_count_summer,
             pos_summer, mod_summer, rob_summer)
)

write.xlsx(metrics_df,
           "Network_Comparison_Summary_Table_Bacterioplankton.xlsx",
           overwrite=TRUE)

cat("\n✔ Summary table saved: Network_Comparison_Summary_Table_Bacterioplankton.xlsx\n")


###########################################################
## Re-drawn Figure 6 (boxplots)
###########################################################
deg_spring <- degree(spring$g)
deg_summer <- degree(summer$g)

degree_df <- data.frame(
  Degree = c(deg_spring, deg_summer),
  Season = rep(c("Spring","Summer"),
               c(length(deg_spring), length(deg_summer)))
)

w_spring <- abs(spring$edge_list$weight)
w_summer <- abs(summer$edge_list$weight)

weight_df <- data.frame(
  Weight = c(w_spring, w_summer),
  Season = rep(c("Spring","Summer"),
               c(length(w_spring), length(w_summer)))
)

png("Example_Network_Summary_Boxplot_Bacterioplankton.png",
    width=3000, height=2600, res=300)

par(mfrow=c(2,2), oma=c(2,2,1,1), mar=c(5,5,4,2),
    cex.main=1.6, cex.lab=1.5, cex.axis=1.4)

boxplot(Degree ~ Season, data=degree_df,
        col=c("#4DAF4A","#377EB8"),
        main="A. Node Degree Distribution",
        ylab="Degree", xlab="")

boxplot(Weight ~ Season, data=weight_df,
        col=c("#4DAF4A","#377EB8"),
        main="B. Edge Weight Strength",
        ylab="|Correlation|", xlab="")

barplot(rbind(c(pos_spring,pos_summer), c(neg_spring,neg_summer)),
        names=c("Spring","Summer"),
        col=c("steelblue","indianred"),
        main="C. Positive vs Negative",
        ylab="Proportion")
legend("topright", legend=c("Positive","Negative"),
       fill=c("steelblue","indianred"), bty="n", cex=1.3)

barplot(c(rob_spring, rob_summer),
        names=c("Spring","Summer"),
        col=c("#4DAF4A","#377EB8"),
        main="D. Robustness (AUC)",
        ylab="AUC")

dev.off()
cat("\n✔ Figure 6 updated.\n")


###########################################################
## Save workspace
###########################################################
save(
  spring, summer,
  Phylum_colors_spring, Phylum_colors_summer,
  spring_res, summer_res,
  robustness_df, metrics_df,
  file="Network_Analysis_Workspace_Bacterioplankton.RData"
)
cat("\n✔ Workspace saved: Network_Analysis_Workspace_Bacterioplankton.RData\n")


###########################################################
## Step H — Figure 7: Robustness Curves
###########################################################
png("Figure7_Robustness_Curves_Bacterioplankton.png",
    width=3000, height=2200, res=300)

ggplot(robustness_df,
       aes(x=Fraction_Removed, y=Fraction_Remaining, color=Season)) +
  geom_line(linewidth=1.6) +
  labs(title="Bacterioplankton",
       x="Fraction of Nodes Removed",
       y="Largest Component Ratio") +
  scale_color_manual(values=c(Spring="forestgreen", Summer="tomato")) +
  theme_bw() +
  theme(text=element_text(size=24))

dev.off()

cat("\n✔ Figure 7 saved: Example_Robustness_Curves_Bacterioplankton.png\n")


###########################################################
## Reload workspace & update distributions
###########################################################
load("Network_Analysis_Workspace_Bacterioplankton.RData")
cat("\n✔ Workspace restored.\n")

library(igraph)
library(openxlsx)

spring$degree <- degree(spring$g)
summer$degree <- degree(summer$g)
spring$edge_weight <- abs(E(spring$g)$weight)
summer$edge_weight <- abs(E(summer$g)$weight)

wb <- loadWorkbook("Network_Comparison_Summary_Table_Bacterioplankton.xlsx")
removeWorksheet(wb, "Distributions")
saveWorkbook(wb, "Network_Comparison_Summary_Table_Bacterioplankton.xlsx",
             overwrite=TRUE)

add_distributions_to_metrics(
  "Network_Comparison_Summary_Table_Bacterioplankton.xlsx",
  spring, summer, "Bacterioplankton"
)
