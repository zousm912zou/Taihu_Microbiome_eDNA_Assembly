############################################################
# Null Model Analyses: βNTI, RC_bray, and Neutral Model
# Complete Script for Reproducing Figure 5 and Figure S7
#
# Required Input Files:
#   ASV.csv
#   Neutral.csv
#   Group.csv
#   Tree.nwk
#   Taxonomy.csv
#
# All code is directly adapted from the ISME manuscript analyses.
# No analytical logic, parameters, or graphical settings were modified.
############################################################


############################################################
# Part 1. βNTI (requires Tree.nwk)
#   Inputs:
#     ASV.csv   – OTU/ASV table (rows = samples, columns = ASVs)
#     Group.csv – metadata table (1st column = SampleID, 2nd column = Season)
#     Tree.nwk  – phylogenetic tree (tip labels = ASV IDs)
############################################################

library(readr)
library(dplyr)
library(tibble)
library(ape)
library(picante)
library(gridExtra)
library(future.apply)
library(gridExtra)


## -----------------------
## Parameters
## -----------------------
otu_file  <- "ASV.csv"
meta_file <- "Group.csv"
tree_file <- "Tree.nwk"

seasons_to_run <- c("Spring", "Summer")
reps_null      <- 199
workers_use    <- 2
set.seed(123)

############################################################
# 1. Load OTU table (ASV.csv)
############################################################

otu_raw <- read_csv(otu_file, show_col_types = FALSE)

# Force first column to be SampleID
names(otu_raw)[1] <- "SampleID"

otu_df <- otu_raw %>%
  mutate(SampleID = trimws(as.character(SampleID)))

asv_cols <- setdiff(names(otu_df), "SampleID")

otu_mat <- otu_df %>%
  mutate(across(all_of(asv_cols), ~ suppressWarnings(as.numeric(.)))) %>%
  column_to_rownames("SampleID") %>%
  as.matrix()

############################################################
# ---- Added step (Speed-up): Filter rare ASVs (< 5 total abundance)
############################################################
otu_mat <- otu_mat[, colSums(otu_mat) >= 5, drop = FALSE]
cat("After filtering ASVs with total abundance < 5: ASVs =", ncol(otu_mat), "\n")
############################################################

############################################################
# 2. Load metadata (Group.csv) and standardize Season labels
############################################################

meta_raw <- read_csv(meta_file, show_col_types = FALSE)

# Force 1st col = SampleID, 2nd col = Season
names(meta_raw)[1] <- "SampleID"
if (ncol(meta_raw) < 2) {
  stop("Group.csv must contain at least two columns: SampleID and Season.")
}
names(meta_raw)[2] <- "Season"

meta <- meta_raw %>%
  mutate(
    SampleID = trimws(as.character(SampleID)),
    Season   = trimws(as.character(Season)),
    Season   = dplyr::recode(
      Season,
      "spring" = "Spring", "SPRING" = "Spring",
      "summer" = "Summer", "SUMMER" = "Summer",
      .default = Season
    )
  )

############################################################
# 3. Load phylogenetic tree and align ASVs
############################################################

tree <- read.tree(tree_file)

clean_id <- function(x) {
  x <- trimws(as.character(x))
  x <- gsub("[\uFEFF\u200B]", "", x)  # remove BOM / zero-width chars
  tolower(x)
}

colnames(otu_mat) <- clean_id(colnames(otu_mat))
tree$tip.label    <- clean_id(tree$tip.label)

common_asv <- intersect(colnames(otu_mat), tree$tip.label)
if (length(common_asv) < 3) {
  stop("Too few ASVs overlap between ASV.csv and Tree.nwk. Check ASV IDs.")
}

otu_mat <- otu_mat[, common_asv, drop = FALSE]
tree    <- keep.tip(tree, common_asv)

############################################################
# 4. Align samples between OTU matrix and metadata
############################################################

common_samples <- intersect(rownames(otu_mat), meta$SampleID)
if (length(common_samples) < 3) {
  stop("Too few shared samples between ASV.csv and Group.csv.")
}

otu_mat <- otu_mat[common_samples, , drop = FALSE]
meta    <- meta   %>% filter(SampleID %in% common_samples)

cat("After alignment: samples =", nrow(otu_mat),
    " | ASVs =", ncol(otu_mat), "\n")

############################################################
# 5. Compute global cophenetic distance matrix
############################################################

D_global <- cophenetic(tree)

############################################################
# 6. Stable βNTI function
############################################################

compute_betaNTI_stable <- function(comm, D_full, reps = 199, workers = 2, seed = 123) {

  # Keep ASVs with non-zero abundance
  comm <- comm[, colSums(comm) > 0, drop = FALSE]
  if (ncol(comm) < 3) stop("Too few ASVs in this subset.")

  # Align OTU table to distance matrix
  taxa <- intersect(colnames(comm), rownames(D_full))
  if (length(taxa) < 3) stop("Too few ASVs shared with distance matrix.")

  comm  <- comm[, taxa, drop = FALSE]
  D_sub <- as.matrix(D_full[taxa, taxa])

  # Observed abundance-weighted βMNTD
  obs <- as.matrix(
    picante::comdistnt(comm, D_sub, abundance.weighted = TRUE)
  )

  # Parallel computation
  oplan <- future::plan()
  on.exit(future::plan(oplan), add = TRUE)
  future::plan(future::multisession, workers = workers)
  set.seed(seed)

  # Null distribution (taxaShuffle)
  rand_list <- future.apply::future_lapply(
    seq_len(reps),
    function(i) {
      as.matrix(
        picante::comdistnt(
          comm,
          picante::taxaShuffle(D_sub),
          abundance.weighted = TRUE
        )
      )
    },
    future.seed = TRUE
  )

  rand <- array(unlist(rand_list), dim = c(nrow(obs), ncol(obs), reps))

  mu <- apply(rand, c(1, 2), mean)
  sd <- apply(rand, c(1, 2), sd)
  sd[sd == 0 | !is.finite(sd)] <- NA_real_

  Z <- (obs - mu) / sd
  diag(Z) <- NA_real_
  Z[!is.finite(Z)] <- NA_real_

  Z
}

############################################################
# 7. Run βNTI for each season and extract vectors
############################################################

bnti_vec_long <- list()

for (s in seasons_to_run) {

  sams <- intersect(meta$SampleID[meta$Season == s], rownames(otu_mat))
  if (length(sams) < 3) {
    warning("Season ", s, ": fewer than 3 samples, skipped.")
    next
  }

  comm <- otu_mat[sams, , drop = FALSE]

  bnti <- compute_betaNTI_stable(
    comm, D_global,
    reps = reps_null, workers = workers_use, seed = 123
  )

  write.csv(as.matrix(bnti), paste0("betaNTI_", s, ".csv"))

  v <- bnti[upper.tri(bnti)]
  v <- v[is.finite(v)]

  cat("Season ", s,
      " | samples = ", length(sams),
      " | ASVs_used = ", sum(colSums(comm) > 0),
      " | finite pairs = ", length(v),
      " | reps = ", reps_null,
      " | workers = ", workers_use, "\n", sep = "")

  if (length(v) > 0) {
    bnti_vec_long[[s]] <- tibble(Season = s, betaNTI = v)
  }
}

df_plot <- dplyr::bind_rows(bnti_vec_long)
if (nrow(df_plot) == 0) {
  stop("No valid βNTI values produced.")
}

readr::write_csv(df_plot, "betaNTI_vectors_combined.csv")
cat("Saved: betaNTI_vectors_combined.csv\n")

############################################################
# 8. Density + violin plot for βNTI
############################################################

title_size  <- 18
axis_title  <- 16
axis_text   <- 14
legend_ttl  <- 14
legend_txt  <- 13

p_density <- ggplot(df_plot, aes(betaNTI, fill = Season)) +
  geom_density(alpha = .45) +
  geom_vline(xintercept = c(-2, 2), linetype = "dashed") +
  labs(title = "βNTI distribution by season",
       x = "βNTI",
       y = "Density") +
  theme_classic() +
  theme(
    plot.title   = element_text(size = title_size, face = "bold"),
    axis.title   = element_text(size = axis_title),
    axis.text    = element_text(size = axis_text),
    legend.title = element_text(size = legend_ttl),
    legend.text  = element_text(size = legend_txt)
  )

p_violin <- ggplot(df_plot, aes(Season, betaNTI, fill = Season)) +
  geom_violin(trim = FALSE, alpha = .45) +
  geom_boxplot(width = .15, outlier.shape = NA) +
  geom_hline(yintercept = c(-2, 2), linetype = "dashed") +
  labs(title = "βNTI by season",
       x = NULL,
       y = "βNTI") +
  theme_classic() +
  theme(
    plot.title   = element_text(size = title_size, face = "bold"),
    axis.title   = element_text(size = axis_title),
    axis.text    = element_text(size = axis_text),
    legend.title = element_text(size = legend_ttl),
    legend.text  = element_text(size = legend_txt)
  )

g <- gridExtra::arrangeGrob(p_density, p_violin,
                            ncol = 1, heights = c(2, 2))

ggsave("Example_betaNTI_by_season_combined.png",
       g, width = 7.5, height = 7.5, dpi = 300)

cat("Saved: betaNTI_by_season_combined.png\n")

############################################################
# 9. Summary statistics + Wilcoxon test
############################################################

sumtab <- df_plot %>%
  group_by(Season) %>%
  summarise(
    n_pairs   = n(),
    mean      = mean(betaNTI, na.rm = TRUE),
    median    = median(betaNTI, na.rm = TRUE),
    sd        = sd(betaNTI, na.rm = TRUE),
    p_lt_neg2 = mean(betaNTI < -2, na.rm = TRUE),
    p_gt_pos2 = mean(betaNTI >  2, na.rm = TRUE),
    p_det     = mean(abs(betaNTI) > 2, na.rm = TRUE),
    .groups   = "drop"
  )

readr::write_csv(sumtab, "betaNTI_summary_by_season.csv")
cat("Saved: betaNTI_summary_by_season.csv\n")

if (dplyr::n_distinct(df_plot$Season) >= 2) {
  wt <- wilcox.test(betaNTI ~ Season, data = df_plot)
  writeLines(paste0("Wilcoxon p = ", signif(wt$p.value, 6)),
             "betaNTI_wilcoxon_result.txt")
  cat("Wilcoxon p = ", signif(wt$p.value, 6), "\n")
}


############################################################
# Part 2. RC_bray (abundance-based null model)
############################################################

suppressPackageStartupMessages({
  library(tidyverse)
  library(vegan)
  library(ggpubr)
})

# -------- Input paths --------
otu_fp  <- "ASV.csv"
tax_fp  <- "Taxonomy.csv"
meta_fp <- "Group.csv"

dir.create("fig",    showWarnings = FALSE)
dir.create("tables", showWarnings = FALSE)

# -------- Load & align data --------
otu_raw  <- read.csv(otu_fp,  check.names = FALSE)
tax_raw  <- read.csv(tax_fp,  check.names = FALSE)
meta_raw <- read.csv(meta_fp, check.names = FALSE)

if (is.na(names(otu_raw)[1])  || names(otu_raw)[1]  == "") names(otu_raw)[1]  <- "SampleID"
if (is.na(names(meta_raw)[1]) || names(meta_raw)[1] == "") names(meta_raw)[1] <- "SampleID"

otu_id_col  <- names(otu_raw)[1]
meta_id_col <- names(meta_raw)[1]

common_samples <- intersect(otu_raw[[otu_id_col]], meta_raw[[meta_id_col]])

otu_f  <- dplyr::filter(otu_raw,  .data[[otu_id_col]] %in% common_samples)
meta_f <- dplyr::filter(meta_raw, .data[[meta_id_col]] %in% common_samples)

rownames(otu_f)  <- otu_f[[otu_id_col]]
otu_f            <- otu_f[, setdiff(names(otu_f), otu_id_col), drop = FALSE]
rownames(meta_f) <- meta_f[[meta_id_col]]

tax_id_col <- names(tax_raw)[1]
keep_asv   <- intersect(colnames(otu_f), tax_raw[[tax_id_col]])
if (length(keep_asv) > 0) {
  otu_f <- otu_f[, keep_asv, drop = FALSE]
}

otu_f  <- otu_f[rowSums(otu_f) > 0, , drop = FALSE]
otu_f  <- otu_f[, colSums(otu_f) > 0, drop = FALSE]
meta_f <- meta_f[rownames(otu_f), , drop = FALSE]

season_col <- names(meta_f)[2]
region_col <- names(meta_f)[3]

meta_min <- meta_f %>%
  dplyr::select(
    Season = all_of(season_col),
    Region = all_of(region_col)
  ) %>%
  dplyr::mutate(SampleID = rownames(meta_f))

############################################################
# RC_bray computation function
############################################################

calc_RC_bray <- function(comm, reps = 199) {

  comm <- as.matrix(comm)
  obs  <- vegdist(comm, method="bray")

  nulls <- replicate(reps, {
    comm_null <- apply(comm, 2, function(x) sample(x))
    vegdist(comm_null, method = "bray")
  })

  mean_null <- apply(nulls, 1, mean)
  sd_null   <- apply(nulls, 1, sd)

  rc <- (obs - mean_null) / sd_null
  as.dist(rc)
}

# Compute RC_bray
rcb <- calc_RC_bray(otu_f, reps = 199)
saveRDS(rcb, file = "tables/RCbray_result_ASV.rds")

############################################################
# Convert RC_bray to long format for plotting
############################################################

get_pairs_long <- function(mat) {
  m  <- as.matrix(mat)
  m[lower.tri(m, diag = TRUE)] <- NA
  df <- as.data.frame(as.table(m))
  df <- df[!is.na(df$Freq), ]
  colnames(df) <- c("Sample1", "Sample2", "value")
  df
}

rcb_long <- get_pairs_long(rcb) %>%
  dplyr::left_join(
    meta_min %>% dplyr::rename(
      Sample1 = SampleID, Season1 = Season, Region1 = Region),
    by = "Sample1"
  ) %>%
  dplyr::left_join(
    meta_min %>% dplyr::rename(
      Sample2 = SampleID, Season2 = Season, Region2 = Region),
    by = "Sample2"
  ) %>%
  dplyr::mutate(
    SameSeason   = if_else(Season1 == Season2, "Within-season", "Cross-season"),
    Season_pair  = if_else(Season1 == Season2, as.character(Season1), "Cross"),
    SameRegionWS = dplyr::case_when(
      Season1 == Season2 & Region1 == Region2 ~ "SameRegion",
      Season1 == Season2 & Region1 != Region2 ~ "DifferentRegion",
      TRUE ~ NA_character_
    )
  )

write.csv(rcb_long, "tables/RCbray_pairs_long.csv", row.names = FALSE)

############################################################
# RC_bray boxplot (within-season)
############################################################

rcb_ws <- rcb_long %>%
  dplyr::filter(SameSeason == "Within-season", !is.na(Season_pair))

stat_test <- ggpubr::compare_means(
  value ~ Season_pair,
  data  = rcb_ws,
  method = "wilcox.test"
)

p_rcb_season <- ggplot(rcb_ws,
                       aes(x = Season_pair, y = value, fill = Season_pair)) +
  geom_boxplot(width = 0.65, outlier.shape = 21, size = 0.35) +
  geom_hline(yintercept = c(-0.95, 0.95),
             linetype = "dashed", color = "grey40", size = 0.4) +
  annotate("text", x = 1.5, y =  1.35,
           label = "Dispersal limitation (> +0.95)",
           size = 3.1, color = "grey20", fontface = "italic") +
  annotate("text", x = 1.5, y = -1.35,
           label = "Homogenizing dispersal (< -0.95)",
           size = 3.1, color = "grey20", fontface = "italic") +
  annotate("text", x = 1.5, y =  0.0,
           label = "Drift (|RC_bray| ≤ 0.95)",
           size = 3.0, color = "grey30", fontface = "italic") +
  scale_fill_manual(values = c("Spring"="#F4A582","Summer"="#92C5DE")) +
  labs(x = NULL, y = "RC_bray") +
  theme_bw() +
  theme(
    panel.grid = element_blank(),
    axis.text  = element_text(size = 11),
    axis.title = element_text(size = 12),
    plot.title = element_text(size = 13, face = "bold"),
    legend.position = "none"
  ) +
  ggpubr::stat_compare_means(
    comparisons = list(c("Spring","Summer")),
    method = "wilcox.test",
    label  = "p.format",
    label.y = 2.2
  )

ggsave("fig/RCbray_within_season_box_annotated.png",
       p_rcb_season, width = 4.8, height = 3.5, dpi = 600)

rcb <- readRDS("tables/RCbray_result_ASV.rds")


############################################################
# Part 3. Neutral Community Model (MicEco)
############################################################

rm(list = ls())

if (!requireNamespace("devtools", quietly = TRUE)) install.packages("devtools")
if (!requireNamespace("ggimage", quietly = TRUE)) install.packages("ggimage")
if (!requireNamespace("plyr", quietly = TRUE)) install.packages("plyr")
if (!requireNamespace("patchwork", quietly = TRUE)) install.packages("patchwork")

library(devtools)
library(ggplot2)
library(ggimage)
library(plyr)
library(patchwork)

if (!requireNamespace("remotes", quietly = TRUE)) install.packages("remotes")
if (!requireNamespace("MicEco", quietly = TRUE)) {
  remotes::install_github("Russel88/MicEco")
}
library(MicEco)

# Load OTU & metadata
otu_table <- read.csv(file = "Neutral.csv", row.names = 1)
group_info <- read.csv(file = "Group.csv")

# Split by season
spring_samples <- group_info[group_info$Season == "Spring","Sample"]
summer_samples <- group_info[group_info$Season == "Summer","Sample"]

otu_spring <- otu_table[, colnames(otu_table) %in% spring_samples]
otu_summer <- otu_table[, colnames(otu_table) %in% summer_samples]

# Neutral model plotting function
plot_season <- function(otu_data, season_name) {

  res <- neutral.fit(t(otu_data))

  m  <- res[[1]][1]
  N  <- res[[1]][4]
  Nm <- N * m
  r2 <- res[[1]][3]
  out <- res[[2]]

  out$group <- with(out,
                    ifelse(freq < Lower, "#509579",
                           ifelse(freq > Upper, "#cf9198", "#485970")))

  data_summary <- as.data.frame(table(out$group))
  colnames(data_summary) <- c("group","nums")
  data_summary$type <- c("med","low","high")
  data_summary$percentage <- round(data_summary$nums / sum(data_summary$nums) * 100, 1)
  data_summary$label <- paste(data_summary$type,
                              paste(data_summary$percentage,"%"))

  p1 <- ggplot(data = out) +
    geom_line(aes(x = log(p), y = freq.pred), size = 1.2, linetype = 1) +
    geom_line(aes(x = log(p), y = Lower),     size = 1.2, linetype = 2) +
    geom_line(aes(x = log(p), y = Upper),     size = 1.2, linetype = 2) +
    geom_point(aes(x = log(p), y = freq, color = group), size = 1.5) +
    xlab("log10(mean relative abundance)") +
    ylab("Occurrence frequency") +
    scale_colour_manual(values = c("#485970","#cf9198","#509579")) +
    annotate("rect", xmin=-12.3, xmax=-12.0, ymin=0.95, ymax=0.92, fill="#485970") +
    annotate("text", x=-11.6, y=0.95, label=data_summary$label[1], size=5, hjust=0) +
    annotate("rect", xmin=-12.3, xmax=-12.0, ymin=0.83, ymax=0.80, fill="#509579") +
    annotate("text", x=-11.6, y=0.83, label=data_summary$label[2], size=5, hjust=0) +
    annotate("rect", xmin=-12.3, xmax=-12.0, ymin=0.71, ymax=0.68, fill="#cf9198") +
    annotate("text", x=-11.6, y=0.71, label=data_summary$label[3], size=5, hjust=0) +
    annotate("text", x=-9, y=0.80, label=paste("Nm = ",round(Nm,3)), size=5, hjust=0) +
    annotate("text", x=-9, y=0.70, label=paste("R² = ",round(r2,3)), size=5, hjust=0) +
    ggtitle(season_name) +
    theme(
      panel.background = element_blank(),
      panel.grid = element_blank(),
      axis.line.x = element_line(size=0.5, colour="black"),
      axis.line.y = element_line(size=0.5, colour="black"),
      axis.ticks  = element_line(color="black"),
      axis.text   = element_text(color="black", size=15),
      legend.position = "none",
      legend.background = element_blank(),
      legend.key = element_blank(),
      legend.text = element_text(size=15),
      text = element_text(family="sans", size=15),
      panel.border = element_rect(color="black", fill=NA, size=1)
    )

  return(p1)
}

# Generate Spring + Summer neutral model plots
p_spring <- plot_season(otu_spring, "Spring")
p_summer <- plot_season(otu_summer, "Summer")

final_plot <- p_spring / p_summer
print(final_plot)

ggsave("Example_Neutral model.PNG",
       plot = final_plot, width = 8, height = 6, dpi = 300)
